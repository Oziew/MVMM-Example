package com.example.mvvmretrofitexample.retrofit;

public class RetrofitRequest {
}
