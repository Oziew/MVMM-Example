package com.example.mvvmretrofitexample.retrofit;public interface ApiRequest {
}
