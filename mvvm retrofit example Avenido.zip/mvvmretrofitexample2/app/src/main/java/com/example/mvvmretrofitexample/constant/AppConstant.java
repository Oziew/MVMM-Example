package com.example.mvvmretrofitexample.constant;

public class AppConstant {
    public static final String BASE_URL="https://newsapi.org/v2/";

    public static final String API_KEY="1af94f5fd0f04d78ae979fd48ac18d12";
}
