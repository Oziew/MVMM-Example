package com.example.mvvmretrofitexample.view_model;

public class ArticleViewModel {
}
